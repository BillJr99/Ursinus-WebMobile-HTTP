const app = "CourseList-v1";
const assets = [
  "/",
  "./index.html",
  "./script.js",
  "./images/icon.png",
  "./images/simbaby.jpg",
  "./images/Spectrogram.png",
  "./images/clusternav.jpg"
]

// On install, cache the assets for offline presentation
self.addEventListener("install", installEvent => {
  installEvent.waitUntil(
    caches.open(app).then(cache => {
      cache.addAll(assets)
    })
  )
})

// Intercept fetch requests and check the cache first, serving assets locally
self.addEventListener("fetch", fetchEvent => {
  fetchEvent.respondWith(
    caches.match(fetchEvent.request).then(res => {
      return res || fetch(fetchEvent.request)
    })
  )
})